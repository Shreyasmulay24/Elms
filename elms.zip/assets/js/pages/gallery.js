$( document ).ready(function() {
	new CBPGridGallery( document.getElementById( 'grid-gallery' ) );
});