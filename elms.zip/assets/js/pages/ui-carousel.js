$(document).ready(function(){
    $('.carousel.carousel-slider').carousel({full_width: true});
    
});